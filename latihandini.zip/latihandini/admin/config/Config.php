<?php

define('BASEURL','http://localhost/latihandini/public');