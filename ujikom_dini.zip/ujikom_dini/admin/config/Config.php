<?php

define('BASEURL','http://localhost/ujikom_dini/public');